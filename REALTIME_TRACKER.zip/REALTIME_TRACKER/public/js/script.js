const socket = io();

if (navigator.geolocation) {
    navigator.geolocation.watchPosition(
        (position) => {
            const { latitude, longitude } = position.coords;
            socket.emit("send-location", { latitude, longitude });
        },
        (error) => {
            console.error(error);
        },
        {
            enableHighAccuracy: true,
            timeout: 5000,
            maximumAge: 0,
        }
    );
}

// Initialize the map view
const map = L.map("map").setView([0, 0], 2);
L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
    attribution: "OpenStreetMap"
}).addTo(map);

const markers = {};

// Listen for incoming location updates
socket.on("receive-location", (data) => {
    const { id, latitude, longitude } = data;

    // Check if a marker already exists for this user
    if (markers[id]) {
        // Update the marker's location
        markers[id].setLatLng([latitude, longitude]);
    } else {
        // Create a new marker for this user
        markers[id] = L.marker([latitude, longitude]).addTo(map);
    }
});

// Remove marker when a user disconnects
socket.on("user-disconnected", (id) => {
    if (markers[id]) {
        map.removeLayer(markers[id]);
        delete markers[id];
    }
});
