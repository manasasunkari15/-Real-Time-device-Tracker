const express = require("express");
const app = express();
const path = require("path");
const http = require("http");
const socketio = require("socket.io");

const server = http.createServer(app);
const io = socketio(server);

// Set view engine and static folder
app.set("view engine", "ejs");
app.use(express.static(path.join(__dirname, "public")));

// Socket.io setup for location tracking
io.on("connection", (socket) => {
    console.log(`User connected: ${socket.id}`);

    socket.on("send-location", (data) => {
        // Emit the location data to all clients, including the sender
        io.emit("receive-location", { id: socket.id, ...data });
    });

    socket.on("disconnect", () => {
        console.log(`User disconnected: ${socket.id}`);
        // Notify other clients that a user has disconnected
        io.emit("user-disconnected", socket.id);
    });
});

// Route to render the map page
app.get("/", (req, res) => {
    res.render("index");
});

// Listen on all network interfaces to allow access from other devices
server.listen(3000, '0.0.0.0', () => {
    console.log("Server running on http://<192.168.0.104>:3000");
});
